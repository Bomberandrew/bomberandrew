
# Orologio Fotovoltaico su Netlify con Funzioni Serverless

Questo progetto mostra un orologio digitale che alterna l'ora alla produzione istantanea del tuo impianto fotovoltaico ogni 10/3 secondi.

## 📦 Contenuto

- `index.html` → orologio + valore di produzione
- `netlify/functions/proxy.js` → funzione serverless che chiama l'API di iSolarCloud
- `netlify.toml` → configurazione per Netlify
- `README.md` → questa guida

## 🚀 Come pubblicare

1. Crea un nuovo repository su GitHub
2. Carica questi file (mantieni la struttura delle cartelle)
3. Vai su [https://app.netlify.com/](https://app.netlify.com/)
4. Clicca su **Add new site → Import from Git**
5. Collega il tuo repository GitHub
6. Netlify rileverà automaticamente `index.html` e le funzioni

## 🔗 Verifica dopo il deploy

- Apri il tuo sito su Netlify
- Visita: `/`
- Visita anche: `/.netlify/functions/proxy` → deve mostrare un JSON

